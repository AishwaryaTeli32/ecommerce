import ComingSoon from "./ComingSoon";

const AddressComponent = () => {
    return <ComingSoon />;
};

export default AddressComponent;
